#' Uclust: U-Statistics for Clustering and Classification.
#' 
#' @docType package
#' @name Uclust
NULL
